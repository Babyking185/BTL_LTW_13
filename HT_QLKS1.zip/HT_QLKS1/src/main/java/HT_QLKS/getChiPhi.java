package HT_QLKS;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class getChiPhi {
	@GetMapping("/chiphi")
	public String hienThi() {
		return "chiphi";
	}
}