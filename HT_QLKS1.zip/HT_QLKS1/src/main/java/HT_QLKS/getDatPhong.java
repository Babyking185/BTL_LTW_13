package HT_QLKS;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class getDatPhong {
	@GetMapping("/datphong")
	public String hienThi() {
		return "datphong";
	}
}
