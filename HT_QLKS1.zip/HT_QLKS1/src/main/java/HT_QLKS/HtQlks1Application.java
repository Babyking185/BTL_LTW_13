package HT_QLKS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HtQlks1Application {

	public static void main(String[] args) {
		SpringApplication.run(HtQlks1Application.class, args);
	}

}
