package HT_QLKS;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class getDanhSachPhong {
	@GetMapping("/danhsachphong")
	public String hienThi() {
		return "danhsachphong";
	}
}
